import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.generator.FastAutoGenerator;

/**
 * @Author zhongyufeng
 * @Date 2023/2/27 15:20
 */
public class CodeGenerator {

//    public static final String URL = "jdbc:mysql://10.110.2.207:3306/cm-template?useUnicode=true&allowMultiQueries=true&characterEncoding=utf-8";
//    public static final String USER = "sc-cm";
//    public static final String PASSWORD = "xTCdoJwVCLd#q2B";

    // mes-test
//    public static final String URL = "jdbc:mysql://10.110.2.20:3306/mes?useUnicode=true&characterEncoding=utf8&serverTimezone=Asia/Shanghai&allowMultiQueries=true";
//    public static final String USER = "ems_wms";
//    public static final String PASSWORD = "sc@123";

    // mes-test
    public static final String URL = "jdbc:mysql://10.110.2.20:3306/mes_erp?useUnicode=true&characterEncoding=utf8&serverTimezone=Asia/Shanghai&allowMultiQueries=true";
    public static final String USER = "ems_wms";
    public static final String PASSWORD = "sc@123";

    // mes-test api转换
//    public static final String URL = "jdbc:mysql://10.110.2.20:3306/d_api?useUnicode=true&characterEncoding=utf8&serverTimezone=Asia/Shanghai&allowMultiQueries=true";
//    public static final String USER = "ems_wms";
//    public static final String PASSWORD = "sc@123";

    // 电商dev
//    public static final String URL = "jdbc:mysql://10.110.1.241:3306/mall_brand?useUnicode=true&characterEncoding=utf-8&serverTimezone=Asia/Shanghai";
//    public static final String USER = "root";
//    public static final String PASSWORD = "ruishi123";

    // 包名
    public static final String PACKAGE_NAME = "com.irobotics.api";
    // 表名
    public static final String[] TABLES = new String[]{"t_prod_order", "t_prod_order_detail"};
    // 表前缀
    public static final String TABLE_PREFIX = "t_";

    public static void main(String[] args) {
        String projectPath = System.getProperty("user.dir");//获取项目路径

        FastAutoGenerator.create(URL, USER, PASSWORD)
                .strategyConfig(builder -> {
                    builder.entityBuilder().enableActiveRecord()//开启 ActiveRecord 模型
                            .enableTableFieldAnnotation()
                            .idType(IdType.INPUT);
                })
                //全局配置
                .globalConfig(builder -> {
                    builder.author("chenaixin")
                            .outputDir(projectPath + "/src/main/java")//输出路径
                            .enableSwagger()//开启swagger3
                            .fileOverride()//覆盖文件
                            .disableOpenDir();//不打开文件夹
                })
                //包名配置
                .packageConfig(builder -> {
                    builder.parent(PACKAGE_NAME);
//                            .moduleName(moduleName)
//                            .service("service")
//                            .serviceImpl("service.impl")
//                            .controller("controller")
//                            .entity("model")
//                            .mapper("mapper")
//                            //自定义输出路径，mapper.xml生成到resources目录下
//                            .pathInfo(Collections.singletonMap(OutputFile.mapperXml, projectPath + "/" + moduleName + "/src/main/resources/mapper"));
                })
                //策略配置
                .strategyConfig(builder -> {
                    builder.addInclude(TABLES)
                            .addTablePrefix(TABLE_PREFIX)//表前缀
                            .serviceBuilder().formatServiceFileName("%sService")//去掉Service的 "I" 前缀
                            .controllerBuilder().enableRestStyle()//restful开启
//                            .enableHyphenStyle() //默认开启驼峰
                            .entityBuilder().enableLombok();//开启lombok
                })
                //指定模板文件路径
                .templateConfig(builder -> {
                    builder.controller("/mybatisTemplates/controller.java.vm")
                            .service("/mybatisTemplates/service.java.vm")
                            .serviceImpl("/mybatisTemplates/serviceImpl.java.vm")
                            .entity("/mybatisTemplates/entity.java.vm")
                            .mapper("/mybatisTemplates/mapper.java.vm")
                            .mapperXml("/mybatisTemplates/mapper.xml.vm").build();
                })
                //执行
                .execute();
    }
}
